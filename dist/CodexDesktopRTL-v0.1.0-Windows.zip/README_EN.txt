Codex Desktop RTL - Windows

How to use:
1. Extract the ZIP.
2. Double-click CodexDesktopRTL.exe.
3. If Windows SmartScreen warns, choose More info and Run anyway only if you trust the source.
4. Official Codex Desktop must already be installed.

What it does:
- Does not modify the official Codex installation.
- Creates a local AppData copy.
- Injects an RTL/BiDi fix into the local copy.
- Creates a desktop shortcut named Codex Desktop RTL.

SHA256:
C74F6498B6119225EA6D9562D1F183A7D0AFF2F5F26AE8AF1A8221AF68690752  CodexDesktopRTL.exe
