Codex Desktop RTL - Windows

איך משתמשים:
1. לחלץ את קובץ ה-ZIP.
2. ללחוץ פעמיים על CodexDesktopRTL.exe.
3. אם Windows SmartScreen מזהיר: לבחור More info ואז Run anyway רק אם סומכים על המקור.
4. נדרש ש-Codex Desktop הרשמי כבר יהיה מותקן.

מה זה עושה:
- לא משנה את ההתקנה הרשמית של Codex.
- יוצר עותק מקומי תחת AppData.
- מזריק תיקון RTL/BiDi לעותק המקומי.
- יוצר קיצור דרך בשם Codex Desktop RTL.

SHA256:
C74F6498B6119225EA6D9562D1F183A7D0AFF2F5F26AE8AF1A8221AF68690752  CodexDesktopRTL.exe
